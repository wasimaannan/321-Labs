#include <stdio.h>
#include <pthread.h>
#include <string.h>

void *block1(void *inp){

    int sum = 0;
    char *name = (char*)inp;
    
    for (int i = 0; i < strlen(name); i++){
    	sum += (int)name[i];
    }
    return (void*)sum;
}

void *block2(void *arg){

    int *all = (int*)arg;
    int sum1 = all[0];
    int sum2 = all[1];
    int sum3 = all[2];

    if (sum1 == sum2 && sum2 == sum3){
        printf("Youreka\n");
    } 
    
    else if (sum1 == sum2 || sum2 == sum3 || sum1 == sum3){
        printf("Miracle\n");
    } 
    
    else{
        printf("Hasta la vista\n");
    }
    
    return NULL;
}

int main(){
    char name[3][20] = {"Kuro", "Billu", "Kuro"};

    pthread_t thread1, thread2, thread3, thread4;
    int sumPointers[3];

    pthread_create(&thread1, NULL, block1, name[0]);
    pthread_join(thread1, (void **)&sumPointers[0]);
    pthread_create(&thread2, NULL, block1, name[1]);
    pthread_join(thread2, (void **)&sumPointers[1]);
    pthread_create(&thread3, NULL, block1, name[2]);
    pthread_join(thread3, (void **)&sumPointers[2]);

    pthread_create(&thread4, NULL, block2, sumPointers);
    pthread_join(thread4, NULL);
    return 0;
}


