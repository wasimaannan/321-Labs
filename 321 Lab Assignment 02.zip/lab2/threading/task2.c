#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

int x = 1;

void* block1(void* arg){

	for (int i = 1; i <= 5; i++){
		printf("Thread %d prints %d\n", arg, x);
		x++;
	}
}

int main(){

	pthread_t thread [5];
	
	for (int i = 0; i < 5; i++){
		pthread_create(&thread[i], NULL, block1, (void*)i);
		pthread_join(thread[i], NULL);
		sleep(1);
	}	
	
	printf("The threads have all ended\n");
}

