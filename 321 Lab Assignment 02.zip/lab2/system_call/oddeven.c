#include <stdio.h>
#include <stdlib.h>

void printOddEven(int arr[], int n) {

    printf("\nOdd/Even define each number:\n");
    
    for (int i = 0; i < n; i++) {
        
        if (arr[i] % 2 == 0) {
            printf("%d is even\n", arr[i]);
        } 
        
        else {
            printf("%d is odd\n", arr[i]);
        }
    }
}

int main(int num, char *arr[]) {
    if (num < 2) {
        printf("Try: %s <num1> <num2> ... <numN>\n", arr[0]);
        return 1;
    }

    int n = num - 1;
    int *out = (int *)malloc(n * sizeof(int)); 

    for (int i = 0; i < n; i++) {
        out[i] = atoi(arr[i + 1]);
    }

    printOddEven(out, n);
    free(out); 
    return 0;
}

