#include <stdio.h>
#include <stdlib.h>


int Descending_Compare(const void *a, const void *b) {
    return (*(int *)b - *(int *)a);
}

int main(int num, char *arr[]) {

    if (num < 2) {
        printf("Try: %s <num1> <num2> ... <numN>\n", arr[0]);
        return 1;
    }

    int n = num - 1;
    int *out = (int *)malloc(n * sizeof(int));
     
    for (int i = 0; i < n; i++) {
        out[i] = atoi(arr[i + 1]);
    }

    qsort(out, n, sizeof(int), Descending_Compare);

    printf("Sorted Array in Descending Order: ");
    
    for (int i = 0; i < n; i++) {
        printf("\n%d ", out[i]);
    }
    
    free(out); 
    return 0;
}

