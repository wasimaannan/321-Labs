#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){
    pid_t a, b;
    
    printf("1. Parent Process ID: %d \n", getpid());
    a = fork();
    
    if (a < 0){
        printf("error in creating child \n");
        }
        
    else if ( a == 0){
        printf("2. Child Process ID: %d \n", getpid());
        
        for (int i =3 ; i < 6; i++){
            pid_t b = fork();
            
            if ( b == 0) {
                printf("%d. Grandchild Process ID: %d \n",i,getpid());
                exit(0);
                }
                
            else {
            wait(NULL);
            }
    }
    
    }else{
        wait(NULL);
    }
    
    return 0;
    
 }  
                     
                     
