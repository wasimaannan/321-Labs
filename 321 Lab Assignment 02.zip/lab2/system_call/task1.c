#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {

    FILE *file_ptr;
    
    char filename[100], input[100];

    if (argc != 2) {
        printf("Please provide a filename.\n");
        return 1;
    }

    strcpy(filename, argv[1]);

    file_ptr = fopen(filename, "w");
    
    if (file_ptr == NULL) {
        printf("Unable to open or create the file %s.\n", filename);
        return 1;
    }

    printf("Enter a string (enter '-1' to quit):\n");
    scanf("%s", input);

    while (strcmp(input, "-1") != 0) {
    
        fprintf(file_ptr, "%s\n", input);
        printf("Enter another string (enter '-1' to quit):\n");
        scanf("%s", input);
    }

    fclose(file_ptr);

    return 0;
}

