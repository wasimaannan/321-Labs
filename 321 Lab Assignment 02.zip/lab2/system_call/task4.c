#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int num, char *arr[]) {

    if (num < 2) {
        printf("Try: %s <num1> <num2> ... <numN>\n", arr[0]);
        return 1;
    }

    pid_t childPid = fork();

    if (childPid == 0) {
        execvp("./sort", arr);
        perror("Error in execution of sort.c");
        return 1;
    } 
    
    else if (childPid < 0) {
        perror("Error in generating child process");
        return 1;
    } 
    
    else {
        wait(NULL); 
        pid_t oddevenPid = fork();

        if (oddevenPid == 0) {
            execvp("./oddeven", arr);
            perror("Error in execution of oddeven.c");
            return 1;
        } 
        
        else if (oddevenPid < 0) {
            perror("Error in generating oddeven process");
            return 1;
        } 
        
        else {
            wait(NULL);
        }
    }
    
    int n = num - 1;
    int *out = (int *)malloc(n * sizeof(int));
    
    for (int i = 0; i < n; i++) {
        out[i] = atoi(arr[i + 1]);
    }
    
    free(out);
    return 0;
}

