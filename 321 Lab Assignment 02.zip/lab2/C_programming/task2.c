#include <stdio.h>

int perfectNumber(int num);
    
int main(){

    int num1, num2;
    
    printf("Enter first number: ");
    scanf("%d", &num1);
    
    printf("Enter last number: ");
    scanf("%d", &num2);
    
    for (int i = num1; i <= num2; i++) {
        if (perfectNumber(i)){
            printf("%d\n",i);
            }
        }
     
    return 0;
    
 }
  
int perfectNumber(int num){
 
    int sum = 0;
    
    for (int i = 1; i <= num /2; i++){
        if (num%i == 0){
            sum += i;
        }
    }
    
    return (sum == num) ;
 } 
