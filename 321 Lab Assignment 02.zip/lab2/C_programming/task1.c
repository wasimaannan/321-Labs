#include <stdio.h>

struct Item {
    float quantity;
    float unit_price;
    };
    

int main() {

    struct Item items[3];
    
    int person;
    float total = 0;
    float per_person = 0;
    
    printf("Quantity of Paratha: ");
    scanf("%f", &items[0].quantity);
    
    printf("Unit Price: ");
    scanf("%f",&items[0].unit_price);
    
    printf("Quantity of Vegetables: ");
    scanf("%f", &items[1].quantity);
    
    printf("Unit Price: ");
    scanf("%f",&items[1].unit_price);
    
    printf("Quantity of Mineral Water: ");
    scanf("%f", &items[2].quantity);
    
    printf("Unit Price: ");
    scanf("%f",&items[2].unit_price);
    
    printf("Number of people: ");
    scanf("%d", &person);
    
    for (int i = 0; i < 3; i++){
        total += items[i].quantity * items[i].unit_price ;
        } 
    
    per_person = total / person ;    
    printf("Individual people will pay: %.2f tk\n", per_person);
    
    return 0;
    
    }
