#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main(){
    int fd[2];
    pid_t home;
    pid_t opr;
    char buff[200];
    char buff1[200];

    struct shared {
        char sel[100];
        int b;
    };

    int p = pipe(fd); 
    
    if(p == -1){
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    home = getpid();
    void *s_m;
    int sm_id;

    sm_id = shmget((key_t)101, sizeof(struct shared), 0666 | IPC_CREAT);
    s_m = shmat(sm_id, NULL, 0);
    
    if (s_m == (void *)-1) {
        perror("shmat");
        exit(EXIT_FAILURE);
    }

    printf("Provide Your Input from Given Options:\n");
    printf("1. Type a to Add Money\n");
    printf("2. Type w to Withdraw Money\n");
    printf("3. Type c to Check Balance\n");
    fgets(buff, sizeof(buff), stdin);
    struct shared *s_data = (struct shared*)s_m;
    strcpy(s_data->sel, buff);
    s_data->b = 1000;

    printf("Your selection: %s", s_data->sel);

    opr = fork();
    
    if(opr < 0){
        perror("fork");
        exit(EXIT_FAILURE);
        
    } else if(opr == 0){
        close(fd[0]);
        void *s_m1;
        int sm_id1;

        sm_id1 = shmget((key_t)101, sizeof(struct shared), 0666);
        s_m1 = shmat(sm_id1, NULL, 0);
        if (s_m1 == (void *)-1) {
            perror("shmat");
            exit(EXIT_FAILURE);
        }
        
        struct shared *r_data = (struct shared*)s_m1;

        if(strcmp(r_data->sel, "a\n") == 0){
            printf("Enter amount to be added: ");
            fgets(buff1, sizeof(buff1), stdin);
            int amount = atoi(buff1);
            if(amount > 0){
                r_data->b += amount;
                printf("Updated balance after addition: %d\n", r_data->b);
            } else{
                printf("Adding failed, Invalid amount\n");
            }
            
        } else if(strcmp(r_data->sel, "w\n") == 0){
            printf("Enter amount to be withdrawn: ");
            fgets(buff1, sizeof(buff1), stdin);
            int amount = atoi(buff1);
            if(amount > 0 && amount <= r_data->b){
                r_data->b -= amount;
                printf("Balance withdrawn successfully\nUpdated balance after withdrawal: %d\n", r_data->b);
                
            } else{
                printf("Withdrawal failed, Invalid amount\n");
            }
            
        } else if(strcmp(r_data->sel, "c\n") == 0){
            printf("Your current balance is:%d\n", r_data->b);
            
        } else{
            printf("Invalid selection\n");
        }

        
        write(fd[1], "Thank you for using", strlen("Thank you for using"));
        close(fd[1]);
        exit(EXIT_SUCCESS);
        
    } else{
        wait(NULL);
        close(fd[1]);
        read(fd[0], buff1, sizeof(buff1));
        printf("%s\n", buff1);
        shmdt(s_m);
        shmctl(sm_id, IPC_RMID, NULL);
    }

    return 0;
}

