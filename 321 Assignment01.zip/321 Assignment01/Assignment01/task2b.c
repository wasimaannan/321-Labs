#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *input, *output;
    char curr, prev;
    input = fopen("inp.txt", "r");
    output = fopen("out.txt", "w");
    prev = ' ';
    while ((curr = fgetc(input)) != EOF) {
        if (!(prev == ' ' && curr == ' ')) {
            fputc(curr, output);
        }
        prev = curr;
    }

}

