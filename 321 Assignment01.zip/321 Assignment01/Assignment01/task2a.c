#include <stdio.h>
int main(){
	int a, b;
	printf("Enter first number: %d\n", a);
	scanf("%d", &a);
	printf("Enter second number: %d\n", b);
	scanf("%d", &b);
	printf("%d, %d\n", a, b);
	
	if (a>b){
		printf("%d\n", a-b);
	} else if (a<b){
		printf("%d\n", a+b);
	} else {
		printf("%d\n", a*b);
	}
	return 0;
}
