#include <stdio.h>
#include <string.h>


int main(){
	char password[100];
	printf("Enter new password: %s\n", password);
	scanf("%s", password);
	//printf("%s\n", password);
	int lower, upper, digit, sp = 0;
	for(int i = 0; i < strlen(password); i++){
		if (password[i]>=97 && password[i]<=122){
			lower ++;
		} 
		if (password[i]>=65 && password[i]<=90){
			upper ++;
		}
		if (password[i]>=48 && password[i]<=57){
			digit ++;
		}
		if ((password[i]==95) || (password[i]==35) || (password[i]==36) || (password[i]==64)){
			sp ++;
		}
	}
	if (lower==0){
		printf("Lowercase character missing\n");
	}
	if (upper==0){
		printf("Uppercase character missing\n");
	}
	if (digit==0){
		printf("Digit is missing\n");
	}
	if (sp==0){
		printf("Special character missing\n");
	}
	if ((lower>0) && (upper>0) && (digit>0) && (sp>0)){
		printf("OK\n");
	}
	
	return 0;
		
	
	
}
