#include <stdio.h>
#include <string.h>

int main(){
	char email[50];
	printf("Enter email:\n");
	scanf("%s", email);
	char new[]="sheba.xyz";
	char store[50]="";
	int idx;
	for(int i; i < strlen(email); i++){
		if (email[i] == '@'){
			idx=i;
			break;
		}
    	}
			
    	for (int j=idx+1;j<strlen(email);j++){
		store[j-(idx+1)]=email[j];
	}
	if (strcmp(new,store)==0){
		printf("Email is okay\n");
	} else {
		printf("Email is outdated\n");
	
	}
	return 0;
}
